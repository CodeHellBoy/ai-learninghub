import requests
from flask import Flask, request, render_template_string

app = Flask(__name__)

# Set Mistral AI API key (Use environment variables in production)
API_KEY = "uxujs1O9v9Q9jWq4ARYlyagwxEBLVL73"
MISTRAL_API_URL = "https://api.mistral.ai/v1/chat/completions"

# Chat history storage
chat_history = []

def get_chatbot_response(user_message):
    """Fetch response from Mistral AI API with an educational constraint"""
    try:
        headers = {"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"}
        payload = {
            "model": "mistral-tiny",
            "messages": [
                {"role": "system", "content": "You are an AI chatbot that only provides educational answers. Avoid non-educational topics."},
                {"role": "user", "content": user_message}
            ],
            "max_tokens": 200
        }
        response = requests.post(MISTRAL_API_URL, json=payload, headers=headers)
        response_data = response.json()
        
        return response_data.get("choices", [{}])[0].get("message", {}).get("content", "⚠️ Error: Invalid response from API.").strip()
    except requests.exceptions.RequestException as e:
        return f"⚠️ API Error: {str(e)}"
    except Exception as e:
        return f"⚠️ Unexpected Error: {str(e)}"

@app.route("/", methods=["GET", "POST"])
def chatbot():
    global chat_history

    if request.method == "POST":
        if "user_message" in request.form:
            user_message = request.form["user_message"].strip()
            bot_response = get_chatbot_response(user_message)
            chat_history.insert(0, (user_message, bot_response))
        elif "delete_history" in request.form:
            chat_history.clear()

    return render_template_string("""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>AI LMS Chatbot</title>
        <style>
            body { font-family: 'Poppins', sans-serif; background-color: #0f172a; color: #e2e8f0; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
            .chat-container { width: 400px; background: #1e293b; padding: 20px; border-radius: 12px; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3); }
            .chat-box { height: 350px; overflow-y: auto; border-radius: 8px; padding: 15px; background: #334155; }
            .chat-message { padding: 8px 12px; margin: 8px 0; border-radius: 6px; max-width: 80%; }
            .user-message { background: #3b82f6; text-align: right; margin-left: auto; color: white; }
            .bot-message { background: #64748b; text-align: left; color: white; }
            .chat-input-container { display: flex; gap: 10px; margin-top: 10px; }
            .chat-input { flex: 1; padding: 10px; border-radius: 6px; border: none; outline: none; background: #475569; color: white; }
            .send-btn, .delete-btn { padding: 10px; border-radius: 6px; border: none; cursor: pointer; transition: 0.3s; }
            .send-btn { background: #10b981; color: white; }
            .send-btn:hover { background: #059669; }
            .delete-btn { background: #ef4444; color: white; margin-top: 10px; width: 100%; }
            .delete-btn:hover { background: #dc2626; }
        </style>
    </head>
    <body>
        <div class="chat-container">
            <h2 style="text-align:center;">AI LMS Chatbot</h2>
            <div class="chat-box" id="chatBox">
                {% for user_msg, bot_msg in chat_history %}
                    <div class="chat-message user-message">{{ user_msg }}</div>
                    <div class="chat-message bot-message">{{ bot_msg }}</div>
                {% endfor %}
            </div>
            <form method="post" class="chat-input-container">
                <input type="text" name="user_message" class="chat-input" placeholder="Type a message..." required>
                <button type="submit" class="send-btn">Send</button>
            </form>
            <form method="post">
                <button type="submit" name="delete_history" class="delete-btn">Clear Chat</button>
            </form>
        </div>
    </body>
    </html>
    """, chat_history=chat_history)

if __name__ == "__main__":
    app.run(debug=True)
